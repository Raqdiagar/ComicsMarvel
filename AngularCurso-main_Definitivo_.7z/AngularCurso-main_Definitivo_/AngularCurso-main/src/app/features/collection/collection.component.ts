import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cm-collection',
  templateUrl: './collection.component.html',
  styleUrls: ['./collection.component.scss']
})
export class CollectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
