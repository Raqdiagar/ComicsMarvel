export enum OutputTypes {
  MESSAGE = 'message',
  MODAL = 'modal',
  NOTIFICATION = 'notification'
}
