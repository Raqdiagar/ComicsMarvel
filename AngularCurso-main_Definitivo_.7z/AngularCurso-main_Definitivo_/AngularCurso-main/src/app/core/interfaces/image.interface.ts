export interface Image {
  path: string;
  extension: string;
}
