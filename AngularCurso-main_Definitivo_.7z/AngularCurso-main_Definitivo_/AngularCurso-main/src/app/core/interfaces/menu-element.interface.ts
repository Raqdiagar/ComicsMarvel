export interface MenuElement {
  title: string;
  path: string;
}
