export interface Pagination {
  totalPages: number;
  limit: number;
  page: number;
}
